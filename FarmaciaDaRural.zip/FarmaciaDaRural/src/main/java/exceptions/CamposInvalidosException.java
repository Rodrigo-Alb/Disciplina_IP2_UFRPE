package exceptions;

public class CamposInvalidosException extends RuntimeException {
   public CamposInvalidosException(String msg){
        super(msg); 
    }
}

